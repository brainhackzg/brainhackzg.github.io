This is the source code of the website for the brainhack conference, in Montreal March 2nd & 3rd, 2017. The website can be seen here: 
https://brainhackmtl.github.io/2017/index.html
